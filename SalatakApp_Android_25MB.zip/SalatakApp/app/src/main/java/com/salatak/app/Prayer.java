package com.salatak.app;

public class Prayer {
    public final String name, time;
    public final int hour, minute, soundRes;
    public Prayer(String name, String time, int hour, int minute, int soundRes) {
        this.name = name; this.time = time; this.hour = hour; this.minute = minute; this.soundRes = soundRes;
    }
}
