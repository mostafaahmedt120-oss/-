package com.salatak.app;

import android.Manifest;
import android.app.PendingIntent;
import android.app.AlarmManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends android.app.Activity {
    private static final int NOTIF_REQ = 42;
    private TextView countdown, nextPrayer;
    private final HandlerHolder handler = new HandlerHolder();

    public static Prayer[] prayers(Context c) {
        return new Prayer[]{
                new Prayer("الفجر", "5:20 ص", 5,20, R.raw.adhan_fajr),
                new Prayer("الشروق", "6:44 ص", 6,44, R.raw.adhan),
                new Prayer("الظهر", "12:51 م", 12,51, R.raw.adhan),
                new Prayer("العصر", "4:18 م", 16,18, R.raw.adhan),
                new Prayer("المغرب", "6:57 م", 18,57, R.raw.adhan),
                new Prayer("العشاء", "8:12 م", 20,12, R.raw.adhan)
        };
    }

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.rgb(7,26,38));
        getWindow().setNavigationBarColor(Color.rgb(7,26,38));
        buildUi();
        PrayerScheduler.scheduleAll(this);
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, NOTIF_REQ);
        if (Build.VERSION.SDK_INT >= 31) {
            AlarmManager am = (AlarmManager)getSystemService(ALARM_SERVICE);
            if (!am.canScheduleExactAlarms()) {
                try { startActivity(new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM)); } catch (Exception ignored) {}
            }
        }
        handler.run();
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(20,18,20,10); root.setBackgroundColor(Color.rgb(7,26,38));
        ScrollView scroll = new ScrollView(this); scroll.setFillViewport(true);
        LinearLayout content = new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL);

        TextView title = tv("☪  صلاتك", 30, Color.rgb(242,184,75), true); title.setGravity(Gravity.CENTER); content.addView(title, lp(-1,70));
        TextView sub = tv("في كل وقت… قربك من الله", 14, Color.LTGRAY, false); sub.setGravity(Gravity.CENTER); content.addView(sub, lp(-1,35));

        LinearLayout card = box();
        TextView date = tv(arabicDate(), 17, Color.WHITE, true); date.setGravity(Gravity.CENTER); card.addView(date, lp(-1,50));
        nextPrayer = tv("الصلاة القادمة", 21, Color.rgb(242,184,75), true); nextPrayer.setGravity(Gravity.CENTER); card.addView(nextPrayer, lp(-1,40));
        countdown = tv("--:--:--", 36, Color.WHITE, true); countdown.setGravity(Gravity.CENTER); card.addView(countdown, lp(-1,60));
        content.addView(card, lp(-1,190));

        TextView head = tv("مواعيد الصلاة اليوم", 21, Color.WHITE, true); head.setGravity(Gravity.CENTER); content.addView(head, lp(-1,60));
        for (Prayer p : prayers(this)) addPrayerRow(content, p);

        LinearLayout toggleRow = box();
        TextView t = tv("تشغيل الأذان تلقائياً", 17, Color.WHITE, true); toggleRow.addView(t, new LinearLayout.LayoutParams(0,70,1));
        Switch sw = new Switch(this); sw.setChecked(true); sw.setText(" "); sw.setOnCheckedChangeListener((buttonView, checked) -> {
            getPreferences(MODE_PRIVATE).edit().putBoolean("enabled", checked).apply();
            if (checked) PrayerScheduler.scheduleAll(this); else cancelAlarms();
        }); toggleRow.addView(sw, lp(70,70));
        content.addView(toggleRow, lp(-1,90));

        TextView info = tv("الأذان العادي: الظهر والعصر والمغرب والشروق والعشاء\nأذان الفجر: ملف صوت أذان الفجر", 14, Color.rgb(168,187,196), false); info.setGravity(Gravity.CENTER); content.addView(info, lp(-1,70));
        scroll.addView(content); root.addView(scroll, new LinearLayout.LayoutParams(-1,0,1));
        TextView footer = tv("صلاتك • مواعيدك في مكان واحد", 13, Color.rgb(168,187,196), false); footer.setGravity(Gravity.CENTER); root.addView(footer, lp(-1,40));
        setContentView(root);
    }

    private void addPrayerRow(LinearLayout parent, Prayer p) {
        LinearLayout row = box();
        TextView name = tv(p.name, 18, Color.WHITE, true); row.addView(name, new LinearLayout.LayoutParams(0,68,1));
        TextView time = tv(p.time, 18, Color.rgb(242,184,75), true); time.setGravity(Gravity.CENTER); row.addView(time, lp(105,68));
        parent.addView(row, lp(-1,78));
    }

    private void cancelAlarms() {
        AlarmManager alarm=(AlarmManager)getSystemService(ALARM_SERVICE); Prayer[] ps=prayers(this);
        for(int i=0;i<ps.length;i++){ Intent in=new Intent(this,PrayerAlarmReceiver.class).setAction(PrayerScheduler.ACTION_ADHAN); PendingIntent pi=PendingIntent.getBroadcast(this,100+i,in,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE); alarm.cancel(pi); }
    }

    private String arabicDate(){ return new SimpleDateFormat("EEEE، d MMMM yyyy", new Locale("ar","EG")).format(new Date()); }
    private LinearLayout box(){ LinearLayout l=new LinearLayout(this); l.setOrientation(LinearLayout.HORIZONTAL); l.setGravity(Gravity.CENTER_VERTICAL); l.setPadding(18,0,18,0); l.setBackgroundResource(R.drawable.rounded_card); return l; }
    private TextView tv(String s,float size,int color,boolean bold){ TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color); t.setTypeface(Typeface.DEFAULT,bold?Typeface.BOLD:Typeface.NORMAL); t.setGravity(Gravity.CENTER_VERTICAL); t.setTextDirection(View.TEXT_DIRECTION_RTL); return t; }
    private LinearLayout.LayoutParams lp(int w,int h){ return new LinearLayout.LayoutParams(w,h); }

    private class HandlerHolder {
        final android.os.Handler h=new android.os.Handler();
        void run(){ update(); h.postDelayed(this::run,1000); }
        void update(){
            Calendar now=Calendar.getInstance(); Prayer next=null; Calendar target=null;
            for(Prayer p:prayers(MainActivity.this)){ Calendar c=(Calendar)now.clone(); c.set(Calendar.HOUR_OF_DAY,p.hour); c.set(Calendar.MINUTE,p.minute); c.set(Calendar.SECOND,0); c.set(Calendar.MILLISECOND,0); if(c.after(now)){next=p;target=c;break;} }
            if(next==null){ next=prayers(MainActivity.this)[0]; target=(Calendar)now.clone(); target.add(Calendar.DAY_OF_YEAR,1); target.set(Calendar.HOUR_OF_DAY,next.hour); target.set(Calendar.MINUTE,next.minute); target.set(Calendar.SECOND,0); target.set(Calendar.MILLISECOND,0); }
            long diff=target.getTimeInMillis()-now.getTimeInMillis(); long hh=diff/3600000, mm=(diff/60000)%60, ss=(diff/1000)%60;
            nextPrayer.setText("الصلاة القادمة: "+next.name); countdown.setText(String.format(Locale.US,"%02d:%02d:%02d",hh,mm,ss));
        }
    }
}
