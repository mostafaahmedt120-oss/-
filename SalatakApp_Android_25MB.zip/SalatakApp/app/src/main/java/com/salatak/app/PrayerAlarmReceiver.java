package com.salatak.app;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class PrayerAlarmReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        if (!PrayerScheduler.ACTION_ADHAN.equals(intent.getAction())) return;
        Intent service = new Intent(context, AdhanService.class)
                .putExtra(PrayerScheduler.EXTRA_PRAYER, intent.getStringExtra(PrayerScheduler.EXTRA_PRAYER))
                .putExtra(PrayerScheduler.EXTRA_SOUND, intent.getIntExtra(PrayerScheduler.EXTRA_SOUND, com.salatak.app.R.raw.adhan));
        context.startForegroundService(service);
        PrayerScheduler.scheduleAll(context);
    }
}
