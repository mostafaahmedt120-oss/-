package com.salatak.app;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import java.util.Calendar;

public final class PrayerScheduler {
    public static final String ACTION_ADHAN = "com.salatak.app.ACTION_ADHAN";
    public static final String EXTRA_PRAYER = "prayer";
    public static final String EXTRA_SOUND = "sound";

    private PrayerScheduler() {}

    public static void scheduleAll(Context context) {
        AlarmManager alarm = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        Prayer[] prayers = MainActivity.prayers(context);
        for (int i = 0; i < prayers.length; i++) {
            Prayer p = prayers[i];
            Calendar c = Calendar.getInstance();
            c.set(Calendar.HOUR_OF_DAY, p.hour);
            c.set(Calendar.MINUTE, p.minute);
            c.set(Calendar.SECOND, 0);
            c.set(Calendar.MILLISECOND, 0);
            if (c.getTimeInMillis() <= System.currentTimeMillis()) c.add(Calendar.DAY_OF_YEAR, 1);
            Intent intent = new Intent(context, PrayerAlarmReceiver.class)
                    .setAction(ACTION_ADHAN)
                    .putExtra(EXTRA_PRAYER, p.name)
                    .putExtra(EXTRA_SOUND, p.soundRes);
            PendingIntent pi = PendingIntent.getBroadcast(context, 100 + i, intent,
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            if (Build.VERSION.SDK_INT >= 23) alarm.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, c.getTimeInMillis(), pi);
            else alarm.setExact(AlarmManager.RTC_WAKEUP, c.getTimeInMillis(), pi);
        }
    }
}
