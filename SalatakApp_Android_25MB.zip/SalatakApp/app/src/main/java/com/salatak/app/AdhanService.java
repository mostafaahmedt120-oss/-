package com.salatak.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.media.AudioAttributes;
import android.media.MediaPlayer;
import android.os.Build;
import android.os.IBinder;

public class AdhanService extends Service {
    private static final String CHANNEL_ID = "adhan_channel";
    private MediaPlayer player;

    @Override public void onCreate() {
        super.onCreate();
        createChannel();
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        String prayer = intent.getStringExtra(PrayerScheduler.EXTRA_PRAYER);
        int sound = intent.getIntExtra(PrayerScheduler.EXTRA_SOUND, R.raw.adhan);
        Intent open = new Intent(this, MainActivity.class);
        PendingIntent pi = PendingIntent.getActivity(this, 7, open, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification n = new Notification.Builder(this, CHANNEL_ID)
                .setContentTitle("حان الآن أذان " + (prayer == null ? "الصلاة" : prayer))
                .setContentText("صلاتك — حان وقت الصلاة")
                .setSmallIcon(R.drawable.ic_mosque)
                .setContentIntent(pi)
                .setOngoing(true).build();
        startForeground(77, n);
        if (player != null) { player.release(); player = null; }
        player = MediaPlayer.create(this, sound);
        if (player != null) {
            player.setOnCompletionListener(mp -> { mp.release(); stopForeground(true); stopSelf(); });
            player.start();
        } else { stopForeground(true); stopSelf(); }
        return START_NOT_STICKY;
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = new NotificationChannel(CHANNEL_ID, "أذان صلاتك", NotificationManager.IMPORTANCE_HIGH);
            ch.setDescription("تنبيه وتشغيل الأذان عند موعد الصلاة");
            ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(ch);
        }
    }
    @Override public void onDestroy() { if (player != null) { player.release(); player = null; } super.onDestroy(); }
    @Override public IBinder onBind(Intent intent) { return null; }
}
